RemoveHandler Object.TestEvent, Handler;
