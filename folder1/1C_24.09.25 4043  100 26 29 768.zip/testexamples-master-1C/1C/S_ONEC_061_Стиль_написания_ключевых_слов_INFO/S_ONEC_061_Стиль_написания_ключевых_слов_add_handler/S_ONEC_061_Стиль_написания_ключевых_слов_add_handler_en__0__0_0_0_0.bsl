AddHandler Object.TestEvent, Handler;
