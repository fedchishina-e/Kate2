Procedure ПроверкаСтиля()
    Обработать();
EndProcedure
